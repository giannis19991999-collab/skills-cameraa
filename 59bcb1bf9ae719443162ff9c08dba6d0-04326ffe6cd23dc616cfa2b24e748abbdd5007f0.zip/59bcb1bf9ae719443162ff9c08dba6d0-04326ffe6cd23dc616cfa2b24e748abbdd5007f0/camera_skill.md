# MinMax H3 — Cinematic Camera, Shot & Continuity Skill

## Purpose

This skill defines how to describe cinematic camera language, shot composition, camera movement, shot-reverse-shot dialogue coverage, spatial continuity, eyelines, framing, and editing-oriented shot changes for realistic video generation with MiniMax H3.

The goal is to translate common filmmaking terminology into concrete visual instructions that H3 can execute consistently.

Use explicit physical descriptions whenever possible. Cinematic terminology may be used, but important camera behavior should also be described in concrete terms.

------

# 1. Core Prompting Principle

When describing a shot, define the visual system before describing the action.

Recommended order:

1. Shot type and composition
2. Subject placement
3. Spatial relationship between subjects
4. Environment
5. Character action
6. Eyeline and gaze direction
7. Camera position
8. Camera movement
9. Shot duration and transition
10. Sound when required

Prefer:

> medium two-shot, Evan on the left side of frame and the man on the right, both visible from the waist up, maintaining their established positions throughout the shot.

Instead of:

> cinematic conversation scene.

Concrete spatial information is more important than abstract cinematic adjectives.

------

# 2. Shot Size

## Extreme Wide Shot / Establishing Shot

Use for:

- establishing the location
- showing the overall environment
- showing groups of people
- emphasizing spatial relationships

Describe:

- the entire environment
- approximate subject size in frame
- subject location within the environment
- important background elements

Example:

> Wide establishing shot of the correctional-facility work area. Evan and the other workers appear relatively small within the large outdoor environment.

------

## Wide Shot

The full body remains visible, usually with substantial surrounding environment.

Example:

> Wide shot, Evan fully visible from head to feet, with the surrounding work area clearly visible around her.

------

## Full Shot

The character is framed approximately head to feet with less environmental space than a wide shot.

Example:

> Full-body shot of Evan from head to feet, keeping her entire restrained posture and foot movement visible.

------

## Medium Full Shot

Approximately knees or thighs upward.

Useful when:

- showing body movement
- preserving some environmental context
- emphasizing interaction between characters

------

## Medium Shot

Approximately waist or chest upward.

Useful for:

- dialogue
- interviews
- ordinary character interaction

Example:

> Medium shot of Evan from the waist up, maintaining her gaze toward the man.

------

## Medium Close-Up

Approximately chest or shoulders upward.

Useful for:

- emotional reactions
- dialogue
- subtle facial expressions

------

## Close-Up

Focus primarily on the face or an important object.

Example:

> Close-up of Evan's face as she briefly looks toward the doorway.

------

## Extreme Close-Up

Focus on a small visual detail.

Examples:

- eyes
- hands
- chain links
- keys
- an object being manipulated

Example:

> Extreme close-up of Evan's hand gripping the cleaning cloth.

------

# 3. Two-Shot

A two-shot keeps two characters visible within the same frame.

When using a two-shot, explicitly define:

- left/right placement
- foreground/background relationship
- approximate distance between characters
- whether both remain visible
- whether the camera moves

Example:

> Medium two-shot. Evan stands on the left side of the frame while the man stands several feet away on the right. Both characters remain visible throughout the shot.

Do not simply write:

> Two people talking.

------

# 4. Over-the-Shoulder Shot

An over-the-shoulder shot places one character in the foreground, usually partially visible from behind, while the other character is the primary subject.

Define whose shoulder is visible.

Example:

> Over-the-shoulder shot from behind Evan. The back of Evan's shoulder and part of her head occupy the near foreground while the man faces her in the background.

The foreground character remains spatially consistent with the established scene.

------

# 5. Shot-Reverse-Shot

Shot-reverse-shot is a sequence of separate shots showing two characters from opposite sides of their interaction.

It is NOT a single shot containing both characters.

## Shot A

> Over-the-shoulder from Evan's side. Evan's shoulder is visible in the foreground and the man faces Evan.

## Shot B

> Cut to the reverse angle from the man's side. The man is now seen from behind while Evan faces him.

Maintain:

- the same physical location
- the same distance between characters
- consistent eyelines
- consistent screen direction
- consistent background orientation

The two shots should feel like opposite views of the same physical conversation.

------

# 6. Eyeline

Eyeline means the direction in which a character looks.

Always define important gaze directions explicitly.

Example:

> Evan looks directly toward the man's face.

For a character looking at something off-screen:

> Evan keeps her head turned toward the doorway and looks at the person standing just outside the frame.

Avoid vague descriptions such as:

> Evan looks naturally.

------

# 7. Eyeline Matching

When two characters are speaking across separate shots, their eyelines should correspond.

Example:

> In Evan's shot, Evan looks toward screen right at the man.

Then:

> In the reverse shot, the man looks toward screen left at Evan.

This establishes that they are looking at each other.

------

# 8. Screen Direction

Once two characters are established spatially, preserve their left-right relationship unless an intentional camera transition changes it.

Example:

> Evan remains on screen left and the man remains on screen right.

For a moving character:

> Evan walks from screen left toward screen right while the camera tracks her movement.

Avoid unnecessarily changing the character's screen direction during continuous action.

------

# 9. 180-Degree Rule

For a conversation or interaction between two characters, imagine an axis connecting the characters.

Keep the camera on the same side of this axis unless an intentional crossing is described.

This preserves consistent screen direction.

Example:

> Maintain the established camera side of the conversation. Evan remains screen left and the man remains screen right.

If the camera intentionally crosses the axis:

> The camera slowly moves around the characters and crosses the established interaction axis, visibly changing their screen positions.

Do not describe an axis crossing unless it is actually intended.

------

# 10. Static Camera

A static camera remains fixed in position.

Use explicit language:

> Locked-off static camera. The camera remains completely stationary throughout the shot.

Suitable for:

- documentary observation
- surveillance-like views
- interviews
- restrained realistic scenes
- observational filmmaking

Do not combine "static camera" with unnecessary camera movement.

------

# 11. Pan

A pan rotates the camera horizontally from a fixed position.

Example:

> The camera remains in the same position and slowly pans from left to right, following Evan as she walks.

The camera rotates rather than physically traveling through space.

------

# 12. Tilt

A tilt rotates the camera vertically from a fixed position.

Example:

> The camera slowly tilts upward from Evan's feet to her face.

Do not describe a tilt as the camera physically moving upward.

------

# 13. Push-In / Dolly-In

The camera physically moves closer to the subject.

Example:

> The camera slowly pushes forward toward Evan, gradually changing from a medium shot to a medium close-up.

Use when the increasing proximity is visually important.

------

# 14. Pull-Out / Dolly-Out

The camera physically moves away from the subject.

Example:

> The camera slowly pulls backward, gradually revealing more of the surrounding environment.

------

# 15. Tracking Shot

The camera physically travels with the subject.

Example:

> The camera tracks alongside Evan as she walks down the corridor, maintaining a consistent medium-wide framing.

Define the tracking direction when useful:

> The camera tracks from left to right with Evan.

------

# 16. Follow Shot

The camera follows behind or alongside a moving character.

Example:

> Rear follow shot. The camera follows behind Evan as she walks forward.

For a frontal follow:

> The camera moves backward in front of Evan while maintaining her full-body framing as she walks toward the camera.

------

# 17. Arc / Orbit

The camera moves around the subject while maintaining approximately the same distance.

Example:

> The camera slowly arcs around Evan from her left side toward her front, maintaining the same subject distance.

The camera movement should have a clear direction.

------

# 18. Crane / Vertical Camera Movement

A crane movement changes the camera's vertical position through physical camera movement.

Example:

> The camera slowly rises above the characters, expanding the view of the surrounding work area.

Use only when a significant vertical camera movement is intended.

------

# 19. Handheld Camera

Handheld camera introduces subtle natural camera instability.

Example:

> Handheld documentary camera with subtle natural operator movement while following Evan.

Avoid excessive random shaking unless intentionally requested.

------

# 20. Steadicam / Stabilized Movement

The camera moves smoothly while following the subject.

Example:

> Smooth stabilized tracking shot following Evan as she walks through the corridor.

------

# 21. Rack Focus

Rack focus changes the plane of focus from one subject to another.

Example:

> The man in the foreground is initially sharp while Evan in the background is soft. Focus gradually shifts from the man to Evan as she looks toward him.

The spatial relationship remains unchanged; only the focus changes.

------

# 22. Depth and Foreground Elements

Use foreground elements to establish spatial depth.

Example:

> The camera looks past the man's shoulder in the foreground toward Evan standing several feet away.

Useful foreground elements include:

- shoulders
- door frames
- windows
- railings
- vehicles
- furniture
- environmental objects

Foreground elements should remain physically connected to the scene.

------

# 23. Camera Perspective

## Eye-Level

The camera is approximately at the character's eye height.

Example:

> Eye-level medium shot of Evan.

## Low Angle

The camera is below the subject's eye level and points upward.

Example:

> Low-angle full-body shot looking slightly upward at Evan.

## High Angle

The camera is above the subject and points downward.

Example:

> High-angle shot looking down toward Evan.

## Overhead

The camera is substantially above the scene.

Example:

> Overhead view looking almost directly down at the work area.

------

# 24. Camera Distance Must Match the Description

Do not combine contradictory camera instructions.

Avoid:

> Close-up, showing Evan's entire body and the surrounding room.

Prefer:

> Wide full-body shot showing Evan from head to feet and the surrounding room.

Or:

> Close-up of Evan's face, with only a small portion of the background visible.

------

# 25. Camera Movement During Character Movement

When a character moves, explicitly define whether the camera:

1. remains stationary
2. pans to follow
3. tracks with the character
4. follows behind
5. moves backward in front of the character
6. remains fixed while the character exits the frame

Example:

> Evan walks from screen left toward screen right while the camera remains locked off. She gradually exits the right side of the frame.

This is different from:

> The camera tracks Evan as she walks from left to right.

------

# 26. Continuous Shot

When there is no cut:

> Continuous unbroken shot. No camera cut occurs during the entire action.

Then describe the camera movement as one continuous movement.

Example:

> Continuous shot. The camera remains behind Evan and slowly tracks forward as she walks toward the doorway. There is no cut.

Do not describe separate shots inside a continuous shot.

------

# 27. Intentional Cut

When a shot changes:

> Cut to a new shot from the opposite camera position.

The new shot should explicitly establish:

- camera position
- subject position
- framing
- eyeline
- action continuation

------

# 28. Reaction Shot

A reaction shot focuses on a character's response to something happening off-screen or to another character.

Example:

> Cut to a medium close-up of Evan. She looks toward the man off-screen and pauses briefly, reacting to what he has said.

The off-screen subject should have an established spatial relationship.

------

# 29. Insert Shot

An insert isolates an important object or action detail.

Example:

> Cut to an insert close-up of Evan's hand placing the cleaning cloth on the floor.

Use inserts only when the detail is narratively important.

------

# 30. POV Shot

A point-of-view shot represents what a character sees.

Example:

> POV from Evan's perspective. The man is directly ahead, seen from Evan's eye level.

When useful, explicitly state:

> The camera represents Evan's visual perspective.

------

# 31. Reverse POV

For a reverse perspective:

> Reverse POV from the man's perspective. Evan is directly ahead, maintaining the established distance between them.

------

# 32. Dialogue Coverage

For dialogue between two characters, use one of three clear structures.

### A. Two-Shot

Both characters remain visible.

### B. Shot-Reverse-Shot

Separate alternating shots from opposite sides.

### C. Single-Subject Coverage

One character dominates the frame while the other remains off-screen.

Do not mix these structures ambiguously.

------

# 33. Documentary Camera

For observational documentary footage:

- favor realistic camera placement
- use restrained camera movement
- preserve natural subject behavior
- avoid excessive dramatic camera movement
- allow environmental context to remain visible

Example:

> Observational documentary-style medium-wide shot. The camera remains slightly handheld and follows Evan naturally without dramatic movement.

Avoid relying only on:

> cinematic documentary look.

Describe the actual camera behavior instead.

------

# 34. Interview Framing

For an interview:

> Medium close-up, eye-level camera, subject slightly off-center, looking toward an interviewer just beside the camera.

For direct-to-camera:

> Medium close-up, eye-level camera. Evan looks directly into the lens.

Do not confuse direct-to-camera with an over-the-shoulder interview angle.

------

# 35. Establishing → Action → Reaction

A common cinematic sequence can be described as:

### Shot 1 — Establishing

> Wide shot establishing the location and positions of all relevant characters.

### Shot 2 — Action

> Medium or full shot showing the main action.

### Shot 3 — Reaction

> Medium close-up showing the character's reaction.

The physical positions established in Shot 1 should remain consistent in subsequent shots.

------

# 36. Match on Action

When cutting during movement, continue the same physical action across the cut.

Example:

> Evan reaches toward the door handle.

Then:

> Cut to the opposite angle while Evan's hand continues the same reaching motion and completes the movement.

The second shot begins from the physical state established immediately before the cut.

------

# 37. Continuity Across Cuts

When changing camera angles, preserve:

- character identity
- clothing
- body posture
- object positions
- hand positions
- gaze direction
- screen direction
- environmental layout
- lighting
- physical restraints
- chain position and tension
- ongoing action

A camera cut changes the viewpoint, not the physical state of the scene.

------

# 38. Camera Movement and Physical Objects

Camera movement must not alter physical objects.

For example, during a camera orbit:

> The camera moves around Evan while her clothing, handcuffs, ankle shackles, and chains remain physically attached and continuous.

The camera is changing its viewpoint rather than causing the scene to reset.

------

# 39. Continuation Shot

For continuation generation:

> Treat the final frame of the previous shot as the exact physical starting state of the new shot.

Preserve:

- character position
- body posture
- gaze
- hand position
- foot position
- object position
- camera-relative orientation
- movement direction
- physical momentum
- established restraints

The new camera angle must observe the existing physical state rather than reconstructing it.

------

# 40. Time and Shot Duration

Every shot should correspond to an explicit portion of the requested video duration.

For a 15-second sequence:

> 0–5s: Shot 1
> 5–10s: Shot 2
> 10–15s: Shot 3

Do not describe more action than can physically occur within the available time.

For a continuous shot, describe the action as one uninterrupted timeline.

------

# 41. Preferred Shot Description Template

Use:

> **Shot X — [duration]: [shot type / composition].**
> [Subject placement and spatial relationship.]
> [Character action.]
> [Eyeline / gaze.]
> [Camera position.]
> [Camera movement.]
> [Important continuity details.]

Example:

> **Shot 1 — 0–6s: Medium two-shot.** Evan stands on screen left while the man stands several feet away on screen right. Evan looks directly toward him while speaking. The camera remains at eye level and locked off. Both characters remain visible throughout the shot.

------

# 42. Shot-Reverse-Shot Template

For a conversation:

> **Shot 1 — 0–4s: Over-the-shoulder from Evan's side.** Evan's shoulder occupies the foreground on screen left. The man faces Evan from several feet away. He speaks while looking directly at Evan. The camera remains at eye level.

> **Shot 2 — 4–8s: Reverse over-the-shoulder.** Cut to the opposite side of the interaction. The man is now seen from behind while Evan faces him. Evan responds while maintaining eye contact with the man. The physical distance and environment remain unchanged.

------

# 43. Important Distinction: Camera Cut vs Camera Movement

A camera movement does not automatically create a new shot.

### Continuous movement

> The camera slowly pans from Evan to the man without a cut.

### New shot

> Cut to the man's side of the conversation.

### Continuous movement followed by a cut

> The camera tracks Evan for several seconds, then cuts to a reverse angle showing the man.

Use the word "cut" only when a new shot is intended.

------

# 44. Avoid Ambiguous Cinematic Language

Avoid relying on phrases such as:

- cinematic
- dynamic camera
- dramatic angle
- beautiful composition
- professional filmmaking
- Hollywood style
- interesting camera movement

Instead describe the physical camera behavior.

For example:

Instead of:

> Dynamic cinematic camera.

Use:

> The camera slowly tracks alongside Evan from left to right while maintaining a medium-wide full-body framing.

------

# 45. H3-Compatible Cinematic Language

Preferred:

- wide shot
- full-body shot
- medium shot
- medium close-up
- close-up
- extreme close-up
- two-shot
- over-the-shoulder shot
- reverse angle
- shot-reverse-shot
- POV
- eye-level
- low angle
- high angle
- static camera
- locked-off camera
- pan
- tilt
- push-in
- pull-out
- tracking shot
- follow shot
- arc
- handheld documentary camera
- stabilized camera
- rack focus
- cut to
- continuous shot
- reaction shot
- insert shot
- establishing shot

Whenever a term could be interpreted ambiguously, supplement it with a concrete description of the camera position and subject relationship.

------

# 46. Integration With Physical Restraint Skill

When physical restraints are present, camera language must not override physical continuity.

The camera may change viewpoint, but:

- handcuffs remain attached to the wrists
- ankle shackles remain attached to the ankles
- connecting chains remain continuous
- chain length remains consistent
- chain tension and slack respond to body movement
- ground contact remains physically plausible
- restricted walking remains visible
- body movement remains compatible with the restraints

Camera movement reveals the physical system from a different viewpoint rather than resetting it.

------

# 47. Final Prompting Principle

The best H3 camera descriptions answer five questions:

1. **Where is the camera?**
2. **What is visible in the frame?**
3. **Where are the characters relative to each other?**
4. **What does the camera do?**
5. **Does the shot continue or cut?**

For every important shot, make these relationships explicit.

The goal is not to use the largest number of filmmaking terms.

The goal is to create an unambiguous visual instruction that H3 can physically realize.



# MiniMax H3 Camera Language Translation Skill

## Purpose

This skill converts conventional cinematography and film-directing terminology into explicit physical visual descriptions that MiniMax H3 can more reliably execute.

The goal is to describe camera behavior as observable physical changes in viewpoint, camera position, framing, optical perspective, and movement.

Use positive, concrete, physically observable descriptions. Avoid relying on film terminology alone when the terminology could be interpreted ambiguously.

------

# 1. Core Principle: Translate Film Language into Physical Camera Behavior

Conventional film terminology such as:

- cut
- hard cut
- reverse shot
- shot-reverse-shot
- push-in
- pull-back
- pan
- tilt
- tracking shot
- dolly
- locked camera
- POV
- OTS
- low angle
- high angle
- medium shot
- close-up
- telephoto

should be accompanied by an explicit description of what physically changes in the image.

The model should receive:

**cinematography term → physical camera state → visible result**

Example:

Instead of:

```
Cut to a new angle.
```

Use:

```
Begin with an abrupt editorial transition to a completely different camera position. The camera is now physically located at the opposite side of the room, creating a new viewing direction and a distinctly different perspective.
```

------

# 2. CUT / 切镜头

## Definition

A CUT means an instantaneous editorial transition between two separately established camera states.

The camera does not travel from the first position to the second position.

The second shot begins with the camera already physically established at its new location.

## H3 preferred expression

Use:

```
Begin with a clear editorial cut to a completely new physical camera position.
```

Then immediately define the new position:

```
The new camera is physically located at [specific location], looking toward [specific subject or direction].
```

For a major viewpoint change:

```
The shot begins after an abrupt editorial transition. The camera is now physically established at [new location], creating a completely different viewing direction and perspective from the previous shot.
```

## Stronger cut definition

When the distinction between two shots is especially important:

```
The image changes instantaneously to a separately established camera position. The new shot begins with the camera already physically positioned at [location].
```

## Important rule

Do not rely on:

```
cut to...
```

alone.

Always define:

1. previous camera state if necessary
2. new camera location
3. new camera orientation
4. new framing
5. new optical perspective

The new shot should read as a new physical observation of the same environment.

------

# 3. CUT WITH CHARACTER CONTINUITY

When the camera cuts but the character must remain physically unchanged:

```
Begin with a clear editorial cut to a completely new physical camera position. The environment and character remain in exactly the same physical state at the moment of the cut. Only the camera viewpoint changes.
```

Then explicitly preserve:

- character position
- body posture
- hand position
- object position
- ongoing action
- environment geometry

Example:

```
After the cut, Evan is already kneeling in exactly the same position beside C4, continuing the same wiping motion. Her body position and the physical state of the restroom remain continuous while the camera viewpoint changes completely.
```

This establishes:

**camera continuity = broken**

**physical scene continuity = preserved**

------

# 4. REVERSE SHOT / 反打

Translate a reverse shot into a physical camera relocation.

Instead of:

```
Reverse shot of Evan.
```

Use:

```
Cut to a new camera position on the opposite side of the interaction, facing back toward Evan.
```

For two-person dialogue:

```
The camera cuts to the opposite side of the spatial axis and looks back toward the other character from the established opposing viewpoint.
```

The two characters remain in their established physical positions.

------

# 5. SHOT-REVERSE-SHOT / 正反打

Each shot must have a separately established physical camera position.

Example:

```
Shot A: camera positioned behind Evan's side of the interaction, looking toward the man.
Shot B: editorial cut to the opposite camera position, looking back toward Evan from the man's side.
```

Each shot begins with the camera already physically established in its new position.

Do not describe the transition between the two cameras as camera movement.

------

# 6. PUSH-IN / 缓慢推近

A push-in means the camera physically moves closer to the subject along its viewing direction.

Preferred expression:

```
The camera slowly moves forward toward Evan while maintaining the same viewing direction and subject focus.
```

For a cinematic gradual push:

```
The camera performs a slow, smooth forward movement toward Evan, progressively increasing her relative size within the frame.
```

If the lens perspective should remain stable:

```
The camera moves physically closer while maintaining the established optical perspective and framing direction.
```

Do not use only:

```
zoom in
```

unless an actual optical zoom is intended.

------

# 7. PULL-BACK / 拉远

A physical pull-back means the camera moves backward away from the subject.

Use:

```
The camera slowly moves backward away from Evan, gradually widening the spatial view while maintaining the same viewing direction.
```

If the intended effect is an optical zoom rather than camera movement, explicitly say:

```
The camera remains physically stationary while the lens gradually changes to a wider focal length.
```

Distinguish physical camera movement from optical zoom.

------

# 8. PAN / 横摇

A pan is rotation around the camera's position.

Use:

```
The camera remains physically stationary while rotating horizontally toward the right, keeping the same camera position and changing only the viewing direction.
```

For left:

```
The camera remains physically stationary while rotating horizontally toward the left.
```

------

# 9. TILT / 俯仰

A tilt changes the vertical viewing direction while the camera position remains fixed.

Tilt upward:

```
The camera remains physically stationary while the lens axis gradually tilts upward.
```

Tilt downward:

```
The camera remains physically stationary while the lens axis gradually tilts downward.
```

------

# 10. LOW-ANGLE SHOT / 低机位

Define both camera height and optical direction.

Preferred:

```
The camera is positioned close to floor level, creating a low-angle perspective with the lens axis gently tilted upward toward Evan.
```

If the frame must remain level:

```
The camera roll remains perfectly level. The image stays geometrically upright, with vertical architectural lines remaining vertical and horizontal surfaces remaining horizontal.
```

Important distinction:

**low angle does not mean sideways camera rotation.**

A low-angle camera can look upward while maintaining a perfectly level camera roll.

------

# 11. HIGH-ANGLE SHOT / 高机位

Use:

```
The camera is positioned above the subject, looking downward toward Evan.
```

When appropriate:

```
The camera remains geometrically level while the optical axis is directed downward toward the subject.
```

------

# 12. LOCKED CAMERA / 固定机位

Use explicit physical stability:

```
The camera remains completely stationary in one fixed physical position throughout the shot.
```

For architectural continuity:

```
The camera position, orientation, height, and framing remain unchanged throughout the shot.
```

For a locked-off shot:

```
The camera remains locked in place while the subject performs the action within the frame.
```

------

# 13. TRACKING / 跟拍

A tracking camera physically changes position while following the subject.

Use:

```
The camera moves physically through the environment while maintaining a consistent distance and viewing relationship with Evan.
```

For following from behind:

```
The camera physically travels behind Evan, maintaining her position near the center of the frame.
```

For lateral tracking:

```
The camera moves laterally alongside Evan while maintaining the same relative viewing distance.
```

------

# 14. ORBIT / 环绕

Use:

```
The camera physically moves around Evan along a curved path while maintaining visual focus on her.
```

Specify direction when important:

```
The camera slowly moves clockwise around Evan while continuously maintaining focus on her.
```

------

# 15. TELEPHOTO / 长焦

Telephoto should describe the visual consequence rather than relying only on the word.

Use:

```
Use a telephoto lens perspective with compressed spatial depth, keeping Evan visually prominent against the background.
```

For a medium close-up:

```
Use a telephoto medium close-up, with Evan occupying the primary visual area while the background remains spatially compressed.
```

------

# 16. MEDIUM SHOT / 中景

Define approximate visible body range through visual composition:

```
Frame Evan from approximately the waist upward while retaining enough surrounding environment to establish her spatial relationship with the restroom.
```

------

# 17. MEDIUM CLOSE-UP / 中近景

Use:

```
Frame Evan from approximately the chest or upper torso upward, keeping her face and upper-body expression visually prominent.
```

If the shot needs more environmental context:

```
Use a medium close-up that keeps Evan dominant in the frame while retaining visible environmental context.
```

------

# 18. CLOSE-UP / 近景

Use:

```
Frame Evan's face and upper shoulders prominently, emphasizing subtle facial expression and natural eye movement.
```

------

# 19. EXTREME CLOSE-UP / 特写

Use:

```
Frame a tightly isolated portion of the subject, such as Evan's eyes, hands, or another specified detail.
```

Always specify the actual subject detail.

------

# 20. FOCUS / 对焦

Do not simply say:

```
Focus on Evan.
```

Define focus priority:

```
Evan remains the primary optical focus throughout the shot, with the camera maintaining visual sharpness on her while the background provides contextual spatial information.
```

When focus changes:

```
The optical focus gradually transitions from the man near the entrance to Evan deeper inside the restroom.
```

------

# 21. RACK FOCUS / 拉焦

Use:

```
The camera remains physically stationary while optical focus gradually shifts from [subject A] to [subject B].
```

The physical camera position remains unchanged.

------

# 22. POV / 主观视角

Define whose viewpoint it represents and where the camera physically is.

Example:

```
The camera represents the man's viewpoint and is physically positioned where the man's eyes would be, looking directly toward Evan.
```

POV should establish:

- viewpoint owner
- physical camera location
- viewing direction
- subject of attention

------

# 23. OTS / OVER-THE-SHOULDER / 越肩镜头

Define the foreground character physically.

Use:

```
The camera is positioned behind the man's shoulder, with part of his shoulder and upper body occupying the foreground while Evan remains visible beyond him.
```

If transitioning from OTS to POV:

```
The camera begins behind the man's shoulder and then physically moves forward away from his shoulder, aligning with his viewing direction to establish his direct viewpoint.
```

This is a continuous camera movement, not an editorial cut.

------

# 24. CAMERA POSITION CHANGES WITHOUT A CUT

When the camera physically travels from one position to another during the same shot, explicitly state continuity.

Use:

```
The camera continuously moves from [position A] toward [position B] within the same uninterrupted shot.
```

Do not describe this as a cut.

------

# 25. CUT VS CONTINUOUS CAMERA MOVEMENT

This distinction is critical.

### CUT

```
The image changes instantaneously to a separately established camera position.
```

The camera has:

- new physical location
- new orientation
- new framing
- new perspective

### CONTINUOUS CAMERA MOVE

```
The camera physically travels from its current position to the new position within the same uninterrupted shot.
```

The camera has:

- continuous physical movement
- continuous visual transition
- no editorial viewpoint jump

These two concepts must never be conflated.

------

# 26. CAMERA AXIS AND VIEWPOINT

When the camera moves to the opposite side of a room or interaction, explicitly define the new viewing direction.

Example:

```
The new camera is physically positioned near wall D and looks back toward entrance A, reversing the previous viewing direction.
```

For a doorway viewpoint:

```
The camera is physically positioned at entrance A and looks inward toward the deeper restroom.
```

For a wall-D viewpoint:

```
The camera is physically positioned near wall D beyond C4 and looks back toward the entrance and sink area.
```

------

# 27. CAMERA ROLL / FRAME LEVEL

When the image must remain geometrically upright:

```
The camera roll remains perfectly level throughout the shot. Vertical architectural lines remain vertical and horizontal surfaces remain horizontal. The frame maintains a stable upright horizon.
```

This should be used whenever a low-angle or high-angle perspective might otherwise be interpreted as a tilted frame.

------

# 28. FINAL FRAMING

When a camera movement ends at a specific body area, explicitly define the final composition.

Example:

```
The camera gradually moves closer and finally settles on a tight framing of Evan's lower body, legs, and ankle shackles while retaining the relevant cleaning action.
```

Avoid vague terms such as:

```
The camera ends on Evan's body.
```

Specify:

- final body region
- framing size
- important action
- important environmental context

------

# 29. CAMERA LANGUAGE FOR CONTINUOUS SEQUENCES

When multiple shots belong to the same physical environment, distinguish between:

**physical scene continuity**

and

**camera continuity**.

A cut can change the camera completely while the physical scene remains unchanged.

Preferred structure:

```
The physical environment and character state remain continuous across the editorial cut, while the camera viewpoint changes completely.
```

This is especially important for spatially anchored environments.

------

# 30. PRIORITY RULE

When conventional cinematography terminology and an explicit physical camera description conflict, the explicit physical description takes priority.

Always translate cinematography terminology into:

1. physical camera location
2. camera height
3. camera orientation
4. optical perspective
5. framing
6. camera movement
7. focus
8. final framing

The final H3 prompt should describe what the camera physically does and what the viewer visibly sees, rather than relying on cinematic terminology alone.